/** @type {import('tailwindcss').Config} */
module.exports = {
    darkMode: 'class',
    content: [
      './index.html',
      './src/**/*.{js,ts,jsx,tsx}',
    ],
    theme: {
      container: {
        center: true,
        padding: '2rem',
        screens: {
          '2xl': '1400px',
        },
      },
      extend: {
        colors: {
          border: 'var(--color-border)', // slate-200
          input: 'var(--color-input)', // slate-200
          ring: 'var(--color-ring)', // blue-600
          background: 'var(--color-background)', // white
          foreground: 'var(--color-foreground)', // slate-900
          primary: {
            DEFAULT: 'var(--color-primary)', // blue-600
            foreground: 'var(--color-primary-foreground)', // white
          },
          secondary: {
            DEFAULT: 'var(--color-secondary)', // slate-500
            foreground: 'var(--color-secondary-foreground)', // white
          },
          accent: {
            DEFAULT: 'var(--color-accent)', // sky-500
            foreground: 'var(--color-accent-foreground)', // white
          },
          destructive: {
            DEFAULT: 'var(--color-destructive)', // red-600
            foreground: 'var(--color-destructive-foreground)', // white
          },
          success: {
            DEFAULT: 'var(--color-success)', // emerald-600
            foreground: 'var(--color-success-foreground)', // white
          },
          warning: {
            DEFAULT: 'var(--color-warning)', // amber-600
            foreground: 'var(--color-warning-foreground)', // white
          },
          error: {
            DEFAULT: 'var(--color-error)', // red-600
            foreground: 'var(--color-error-foreground)', // white
          },
          muted: {
            DEFAULT: 'var(--color-muted)', // slate-100
            foreground: 'var(--color-muted-foreground)', // slate-600
          },
          card: {
            DEFAULT: 'var(--color-card)', // slate-50
            foreground: 'var(--color-card-foreground)', // slate-900
          },
          popover: {
            DEFAULT: 'var(--color-popover)', // white
            foreground: 'var(--color-popover-foreground)', // slate-900
          },
        },
        borderRadius: {
          lg: 'var(--radius)',
          md: 'calc(var(--radius) - 2px)',
          sm: 'calc(var(--radius) - 4px)',
        },
        fontFamily: {
          sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
          mono: ['JetBrains Mono', 'Courier New', 'monospace'],
        },
        fontSize: {
          xs: ['0.75rem', { lineHeight: '1rem' }],
          sm: ['0.875rem', { lineHeight: '1.25rem' }],
          base: ['1rem', { lineHeight: '1.5rem' }],
          lg: ['1.125rem', { lineHeight: '1.75rem' }],
          xl: ['1.25rem', { lineHeight: '1.75rem' }],
          '2xl': ['1.5rem', { lineHeight: '2rem' }],
          '3xl': ['1.875rem', { lineHeight: '2.25rem' }],
          '4xl': ['2.25rem', { lineHeight: '2.5rem' }],
        },
        boxShadow: {
          'elevation-1': '0 1px 3px rgba(0, 0, 0, 0.1)',
          'elevation-2': '0 4px 6px rgba(0, 0, 0, 0.1)',
          'elevation-3': '0 10px 25px rgba(0, 0, 0, 0.15)',
        },
        animation: {
          'fade-in': 'fadeIn 150ms ease-out',
          'fade-out': 'fadeOut 150ms ease-out',
          'slide-in': 'slideIn 300ms ease-in-out',
          'slide-out': 'slideOut 300ms ease-in-out',
          'scale-in': 'scaleIn 150ms ease-out',
          'success-bounce': 'successBounce 600ms cubic-bezier(0.34, 1.56, 0.64, 1)',
        },
        keyframes: {
          fadeIn: {
            '0%': { opacity: '0' },
            '100%': { opacity: '1' },
          },
          fadeOut: {
            '0%': { opacity: '1' },
            '100%': { opacity: '0' },
          },
          slideIn: {
            '0%': { transform: 'translateY(-10px)', opacity: '0' },
            '100%': { transform: 'translateY(0)', opacity: '1' },
          },
          slideOut: {
            '0%': { transform: 'translateY(0)', opacity: '1' },
            '100%': { transform: 'translateY(-10px)', opacity: '0' },
          },
          scaleIn: {
            '0%': { transform: 'scale(0.95)', opacity: '0' },
            '100%': { transform: 'scale(1)', opacity: '1' },
          },
          successBounce: {
            '0%, 100%': { transform: 'scale(1)' },
            '50%': { transform: 'scale(1.1)' },
          },
        },
        transitionDuration: {
          '150': '150ms',
          '300': '300ms',
        },
        transitionTimingFunction: {
          'ease-out': 'cubic-bezier(0, 0, 0.2, 1)',
          'ease-in-out': 'cubic-bezier(0.4, 0, 0.2, 1)',
        },
      },
    },
    plugins: [
      require('@tailwindcss/typography'),
      require('@tailwindcss/forms'),
      require('tailwindcss-animate'),
    ],
  }